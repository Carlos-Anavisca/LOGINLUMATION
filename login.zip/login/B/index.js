const app = require('./app');
var mysqlConnection = require('./database/index')

app.get('/', function (req, res) {
    res.status(200).send('PROBANDO NUESTRA API')
})

//SELECCIONAR A TODOS LOS USUARIOS
//Get all users
app.get('/users', (req, res) => {
    console.log('LISTA DE USUARIOS EXITOSA');
    mysqlConnection.query('SELECT * FROM Users;', function (err, rows, fields) {
        if (!err)
            res.send(rows);
        else
            console.log(err);
    });
});


//SELECCIONAR A UN USUARIO POR ID
//Get an users

app.get('/users/:id', (req, res) => {
    mysqlConnection.query('SELECT * FROM Users WHERE idUsuario = ?;', [req.params.id], (err, rows, fields) => {
        if (!err)
            res.send(rows);
        else
            console.log(err);
    });
});


//ELIMINAR UN USUARIO POS ID
//Delete an users
app.delete('/users-delete/:id', (req, res) => {
    mysqlConnection.query('DELETE FROM Users WHERE idUsuario = ?;', [req.params.id], (err, rows, fields) => {
        if (!err)
            res.send('SE HA ELIMINADO EL REGISTRO EXITOSAMENTE.');
        else
            console.log(err);
    });
});

//INSERTAR UN NUEVO USUARIO
//Insert an users
app.post('/create-users', (req, res) => {
    let emp = req.body;
    var sql = "SET @idUsuario = ?;SET @nombre = ?;SET @apellido = ?;SET @fechaNacimiento = ?; SET @direccion = ?; SET @telefono = ?; SET @email = ?; \
    CALL UserAddOrEdit(@idUsuario,@nombre,@apellido,@fechaNacimiento,@direccion,@telefono,@email);";
    mysqlConnection.query(sql, [0, emp.nombre, emp.apellido, emp.fechaNacimiento, emp.direccion, emp.telefono, emp.email], (err, rows, fields) => {
        if (!err)
            //res.send(rows);
            rows.forEach(element => {
                if(element.constructor == Array)
                res.status(200).send('Inserted users id : '+element[0].idUsuario);
            });
        else
            console.log(err);
            res.status(500).send(err);
    });
});






//ACTUALIZAR UN USUARIO
//Update an users
app.put('/update-users', (req, res) => {
    let emp = req.body;
    var sql = "SET @idUsuario = ?;SET @nombre = ?;SET @apellido = ?;SET @fechaNacimiento = ?; SET @direccion = ?; SET @telefono = ?; SET @email = ?; \
    CALL UserAddOrEdit(@idUsuario,@nombre,@apellido,@fechaNacimiento,@direccion,@telefono,@email);";
    mysqlConnection.query(sql, [emp.idUsuario, emp.nombre, emp.apellido, emp.fechaNacimiento, emp.direccion, emp.telefono, emp.email], (err, rows, fields) => {
        if (!err)
            res.send('SE HA ACTUALIZADO EL USUARIO CORRECTAMENTE');
        else
            console.log(err);
    });
});

//------------------------------------------------------------------------------------------------------------------

//TABLA DE PASSWORDS
//SELECCIONAR A TODOS LOS PASSWORD
//Get all users
app.get('/passwords', (req, res) => {
    console.log('LISTA DE PASSWORDS EXITOSA');
    mysqlConnection.query('SELECT * FROM passwordUser;', function (err, rows, fields) {
        if (!err)
            res.send(rows);
        else
            console.log(err);
    });
});

//SELECCIONAR lA CONTRASEÑA UN USUARIO POR ID
//Get an users

app.get('/password/:id', (req, res) => {
    mysqlConnection.query('SELECT * FROM passwordUser WHERE idUsuario = ?;', [req.params.id], (err, rows, fields) => {
        if (!err)
            res.send(rows);
        else
            console.log(err);
    });
});

//ELIMINAR UN PASSWOR POR ID-PASS
//Delete an users
app.delete('/delete-password/:id', (req, res) => {
    mysqlConnection.query('DELETE FROM passwordUser WHERE idPasswordUser = ?;', [req.params.id], (err, rows, fields) => {
        if (!err)
            res.send('SE HA ELIMINADO LA CONTRASEÑA EXITOSAMENTE.');
        else
            console.log(err);
    });
});

//INSERTAR UN NUEVO PASSWORD A UN USUARIO
//Insert an users
app.post('/create-pass', (req, res) => {
    let emp = req.body;
    var sql = "SET @idPasswordUser = ?;SET @idUsuario = ?;SET @contrasena = ?; \
    CALL PassAddOrEdit(@idPasswordUser,@idUsuario,@contrasena);";
    mysqlConnection.query(sql, [emp.idPasswordUser, emp.idUsuario, emp.contrasena], (err, rows, fields) => {
        if (!err)
            //res.send(rows);
            rows.forEach(element => {
                if(element.constructor == Array)
                res.send('Inserted password id : '+element[0].idPasswordUser);
            });
        else
            console.log(err);
    });
});


//ACTUALIZAR UN PASSWORD A UN USUARIO
//Update an users
app.put('/update-pass', (req, res) => {
    let emp = req.body;
    var sql = "SET @idPasswordUser = ?;SET @idUsuario = ?;SET @contrasena = ?; \
    CALL PassAddOrEdit(@idPasswordUser,@idUsuario,@contrasena);";
    mysqlConnection.query(sql, [emp.idPasswordUser, emp.idUsuario, emp.contrasena], (err, rows, fields) => {
        if (!err)
            res.send('SE HA ACTUALIZADO EL PASSWORD CORRECTAMENTE');
        else
            console.log(err);
    });
});
