
const express = require('express');
var app = express();
const bodyparser = require('body-parser');

app.use(bodyparser.json());

//app.use('/api', routes);

app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Access-Control-Allow-Request-Method');
    res.header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, DELETE');
    res.header('Allow', 'GET, POST, OPTIONS, PUT, DELETE');
    next();
});


app.listen(3001, function () {
    console.log('Servidor iniciado en el puerto 3001');
});



module.exports = app;
