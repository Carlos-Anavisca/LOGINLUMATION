const mysql = require('mysql');

var mysqlConnection = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : 'Diosesamor2001',
    database : 'Lumation',
    multipleStatements: true
});

module.exports = mysqlConnection;