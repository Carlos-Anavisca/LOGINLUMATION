import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private http: HttpClient) { }
  users: Observable <any>;
  user: Observable <any>;

  private extractData(res){
    let body = res || {} || [];
    return body;
  } 

/*   getListUsers(){
    const url_api = 'http://localhost:3001/users';
    return this.http.get(url_api, this.httpOptions).pipe(map(this.extractData))
  } */

  getListUsers(): Observable<any>{
    const url_api = 'http://localhost:3001/users';
    return this.http.get(url_api)
  }

  getUserId(): Observable<any> {
    const url_api = 'http://localhost:3001/users/:id';
    return this.http.get(url_api, this.httpOptions).pipe(map(this.extractData))
  }

  deleteUser(idUsuario) : Observable<any> {
    console.log(idUsuario)
    const url_api = 'http://localhost:3001/users-delete/'+idUsuario;
    console.log(url_api)
    return this.http.delete(url_api);
  }

  getInsertUser(data) : Observable<any>{
    let params = JSON.stringify(data);
    console.log(params)
    const url_api = 'http://localhost:3001/create-users';
     return this.http.post(url_api, params, this.httpOptions).pipe(map(this.extractData))
  }

  getUpdateUsers(){
    const url_api = 'http://localhost:3001/update-users';
    return this.http.get(url_api);
  }

  
}
