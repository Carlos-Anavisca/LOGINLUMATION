import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class PassService {

  endpoint = 'http://localhost:3001/'
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json'
    })
  };

  constructor(private http: HttpClient) { }
  passwords: Observable <any>;
  password: Observable <any>;

  getListPass(){
    const url_api = 'http://localhost:3001/passwords';
    return this.http.get(url_api);
  }

  getPassId(){
    const url_api = 'http://localhost:3001/password/:id';
    return (this.password = this.http.get(url_api));
  }

  getDeletePass(){
    const url_api = 'http://localhost:3001/delete-password/:id';
    return this.http.delete(url_api);
  }

  getInsertPass(){
    const url_api = 'http://localhost:3001/create-pass';
    return this.http.get(url_api);
  }

  getUpdatePass(){
    const url_api = 'http://localhost:3001/update-pass';
    return this.http.get(url_api);
  }

}
