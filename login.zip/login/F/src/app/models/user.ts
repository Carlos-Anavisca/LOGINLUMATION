export class User{
    
    constructor(
        public idUsuario: 0,
        public nombre: string,
        public apellido: string,
        public fechaNacimiento: string,
        public direccion: string,
        public telefono: string,
        public email: string       
    ){}
}