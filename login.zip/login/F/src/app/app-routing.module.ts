import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegisterUserComponent } from './components/register-user/register-user.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { HomeComponent } from './components/home/home.component';
import { UserComponent } from './components/user/user.component';
import { PassComponent } from './components/pass/pass.component';
import { RegisterPassComponent } from './components/register-pass/register-pass.component';

const routes: Routes = [

  {path: '', component:LoginComponent},
  {path: 'login', component:LoginComponent},
  {path: 'user', component:UserComponent},
  {path: 'register-user', component:RegisterUserComponent},  
  {path: 'pass', component:PassComponent},
  {path: 'register-pass', component:RegisterPassComponent},
  {path: 'home', component:HomeComponent},
  {path: '**', component:NotFoundComponent}
  


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
