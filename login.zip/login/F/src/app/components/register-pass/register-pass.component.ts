import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-pass',
  templateUrl: './register-pass.component.html',
  styleUrls: ['./register-pass.component.css']
})
export class RegisterPassComponent implements OnInit {
  
  constructor() { }

  ngOnInit() {
  }

}

