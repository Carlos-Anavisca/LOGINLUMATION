import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user.service';
import { User } from '../../models/user';
import { Observable } from 'rxjs';
 

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor(private userService: UserService) { }
  users = '';


  ngOnInit(){
    this.userService.getListUsers().subscribe(
      result => {
        this.users = result;
        console.log(result)
        console.log(this.users);
      },
      error => {
        console.log(<any>error)
      }
    )
  }

  deleteUser(id){

    let idUsuario = id
    console.log(id)
    this.userService.deleteUser(idUsuario).subscribe(
      res => {
        console.log(res)
      },
      err => console.log(err)
      
    )
  }
  
  // ngOnInit() {
  //   this.getListUser();
  // }

  // getListUser(){
  //   this.userService
  //   .getListUsers()
  //   .subscribe((users:User)=>(this.users = users));
  // }


}

