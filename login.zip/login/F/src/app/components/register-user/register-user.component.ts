import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { User } from 'src/app/models/user';
import { FormGroup, Validators, FormControl, FormBuilder } from '@angular/forms';


@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.css']
})
export class RegisterUserComponent implements OnInit {
  user:User = new User(0, '', '', '', '', '', '');
  
  constructor(private rest: UserService, private userForm: FormBuilder) {
   }

   myForm: FormGroup;
   

  ngOnInit() {
    this.myForm = this.userForm.group({
      nombre: new FormControl('',Validators.required),
      apellido: new FormControl('',Validators.required),
      fechaNacimiento: new FormControl('',Validators.required),
      direccion: new FormControl('',Validators.required),
      telefono: new FormControl('',Validators.required),
      email: new FormControl('',Validators.required),

    })

  }


  SaveUser(){

    console.log(this.myForm)

    const data = {
      nombre: this.myForm.value.nombre,
      apellido: this.myForm.value.apellido,
      fechaNacimiento: this.myForm.value.fechaNacimiento,
      direccion: this.myForm.value.direccion,
      telefono: this.myForm.value.telefono,
      email: this.myForm.value.email
    }

    this.rest.getInsertUser(data).subscribe(res => {
      console.log(res)
    },
    err => {
      console.log(err)
    }
    
    )

    
  }
  

}
